package project.server;

// 필요한 클래스 및 패키지 import
import project.Database;
import project.controller.DuplicateController;
import project.controller.MatchController;
import project.controller.SensorController;

import java.io.*;
import java.net.*;

// 클라이언트 요청을 처리하는 RequestHandler 클래스 (Thread를 사용해 처리하기위한 Runnable 인터페이스 구현)
public class RequestHandler implements Runnable {
    private Socket requestSocket; // 나머지 파이 3개와 통신하기 위한 소켓 객체

    // 생성자: 요청 소켓을 초기화
    public RequestHandler(Socket requestSocket) {
        this.requestSocket = requestSocket;
    }

    @Override
    public void run() {
        try (
                // 입력 및 출력 스트림 설정
                BufferedReader in = new BufferedReader(new InputStreamReader(requestSocket.getInputStream()));
                PrintWriter out = new PrintWriter(requestSocket.getOutputStream(), true)
        ) {
            String request;
            // 클라이언트 요청 읽기 및 처리
            while ((request = in.readLine()) != null) {
                System.out.println("Received: " + request); // 요청 출력
                String response = processRequest(request); // 요청 처리
                out.println(response); // 클라이언트에 응답 전송
            }
        } catch (IOException e) {
            e.printStackTrace(); // 예외 발생 시 스택 트레이스 출력
        } finally {
            try {
                requestSocket.close(); // 소켓 닫기
            } catch (IOException e) {
                e.printStackTrace(); // 예외 발생 시 스택 트레이스 출력
            }
        }
    }

    // 요청을 처리하는 메서드
    private String processRequest(String request) {
        Database database = Database.getInstance(); // 데이터베이스 인스턴스 가져오기

        // 요청이 'r'로 시작하는 경우 (학생 정보 등록 요청)
        if (request.charAt(0) == 'r') {
            request = request.substring(1); // 'r' 제거
            String[] parts = request.split("#"); // 받은 사생정보 분리
            // 데이터베이스에 학번이 없는 경우 처리
            if (database.getStudentById(parts[0]) == null) {
                database.saveStudent(parts[0], parts[1], parts[2]); // 학생 정보 저장
                SensorController sensor = new SensorController(); // sensor 처리를 맡는 controller 생성
                sensor.send("3"); // 녹색 LED를 키기 위한 요청
                DuplicateController duplicate = new DuplicateController(); // 중복 처리를 맡는 controller 생성
                duplicate.send("yes"); // 중복 아님 전송
            } else {
                // 중복된 경우 처리
                SensorController sensor = new SensorController(); // sensor 처리를 맡는 controller 생성
                DuplicateController duplicate = new DuplicateController(); // 중복 처리를 맡는 controller 생성
                duplicate.send("no"); // 중복임 전송
                sensor.send("1"); // 노란색 LED를 키기 위한 요청
            }
        }

        // 요청이 'm'로 시작하는 경우 (학생 정보 매칭 요청)
        if (request.charAt(0) == 'm') {
            String studentId = database.getStudentById(request.substring(1)); // 요청에서 학번 추출
            if (studentId == null) {
                // 매칭 실패 시 처리
                SensorController sensor = new SensorController(); // sensor 처리를 맡는 controller 생성
                sensor.send("2"); //Piezo 소리 및 빨간 LED를 키기 위한 요청
            } else {
                // 매칭 성공 시 처리 
                MatchController match = new MatchController(); //학번 매칭을 맡는 controller 생성
                match.send(studentId); //학번에 따른 비밀번호를 Pi 3으로 전송하기 위한 요청
            }
        }

        // 요청이 'w'로 시작하는 경우(외부인 감지)
        if (request.charAt(0) == 'w') {
            SensorController sensor = new SensorController(); // sensor 처리를 맡는 controller 생성
            sensor.send("2"); //Piezo 소리 및 빨간 LED를 키기 위한 요청
        }

        // 처리 결과 반환
        return "Processed: " + request;
    }
}
