package project.server;

import java.io.*;
import java.net.*;
import java.util.concurrent.*;

// 서버 클래스: 클라이언트 요청을 처리하기 위한 메인 서버 구현
public class Server {
    private static final int PORT = 12345; // 서버가 실행될 포트 번호
    private static ExecutorService threadPool = Executors.newFixedThreadPool(10);
    // 고정된 크기의 스레드 풀 생성 (동시에 최대 10개의 요청 처리 가능)

    public static void main(String[] args) {
        // 서버 소켓 초기화 및 클라이언트 연결 대기
        try (ServerSocket serverSocket = new ServerSocket(PORT)) {
            System.out.println("Server is running on port " + PORT); // 서버 시작 메시지 출력

            // 무한 루프: 클라이언트 연결 대기 및 요청 처리
            while (true) {
                Socket clientSocket = serverSocket.accept(); // 클라이언트 연결 수락
                threadPool.execute(new RequestHandler(clientSocket));
                // 클라이언트 요청을 처리하기 위해 RequestHandler 실행
            }
        } catch (IOException e) {
            e.printStackTrace(); // 예외 발생 시 스택 트레이스 출력
        }
    }
}
