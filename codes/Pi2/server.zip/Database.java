package project;

import java.sql.*;

// Database 클래스: 데이터베이스와 연결하고 데이터베이스 관련 작업을 수행
public class Database {
    private static Database instance; // Singleton 패턴을 위한 인스턴스 변수
    private Connection connection; // 데이터베이스 연결 객체

    // 생성자: 데이터베이스 초기화 및 연결 설정
    private Database() {
        try {
            // MySQL JDBC 드라이버 로드
            Class.forName("com.mysql.cj.jdbc.Driver");

            // 데이터베이스 존재 여부 확인 및 생성
            createDatabaseIfNotExists();

            // 데이터베이스 연결 설정
            String url = "jdbc:mysql://localhost:3306/domitory_db?serverTimezone=Asia/Seoul";
            String username = "root"; // MySQL 사용자 이름
            String password = "7179"; // MySQL 비밀번호
            connection = DriverManager.getConnection(url, username, password);
            System.out.println("Connected to the database!");

            // 테이블 존재 여부 확인 및 생성
            createTableIfNotExists();
        } catch (SQLException | ClassNotFoundException e) {
            e.printStackTrace(); // 예외 발생 시 오류 출력
        }
    }

    // Singleton 패턴: Database 인스턴스를 반환
    public static synchronized Database getInstance() {
        if (instance == null) {
            instance = new Database();
        }
        return instance;
    }

    // 데이터베이스가 존재하지 않을 경우 생성
    private void createDatabaseIfNotExists() {
        String url = "jdbc:mysql://localhost:3306/?serverTimezone=Asia/Seoul"; // 데이터베이스 없이 연결
        String username = "root";
        String password = "7179";

        try (Connection tempConnection = DriverManager.getConnection(url, username, password);
             Statement stmt = tempConnection.createStatement()) {

            // 데이터베이스 존재 여부 확인 쿼리
            String checkDatabaseQuery = "SHOW DATABASES LIKE 'domitory_db'";
            ResultSet resultSet = stmt.executeQuery(checkDatabaseQuery);

            // 데이터베이스가 없을 경우 생성
            if (!resultSet.next()) {
                String createDatabaseQuery = "CREATE DATABASE domitory_db";
                stmt.executeUpdate(createDatabaseQuery);
                System.out.println("Database 'domitory_db' created.");
            } else {
                System.out.println("Database 'domitory_db' already exists.");
            }
        } catch (SQLException e) {
            e.printStackTrace(); // SQL 예외 처리
        }
    }

    // 테이블이 존재하지 않을 경우 생성
    private void createTableIfNotExists() {
        String createTableSQL = "CREATE TABLE IF NOT EXISTS students (" +
                "student_id VARCHAR(50) NOT NULL, " + // 학생 ID
                "password VARCHAR(50) NOT NULL, " +  // 비밀번호
                "room_number VARCHAR(50) NOT NULL" + // 방 번호
                ")";

        try (Statement stmt = connection.createStatement()) {
            stmt.executeUpdate(createTableSQL); // 테이블 생성 쿼리 실행
            System.out.println("Table 'students' is ready.");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // 학생 정보를 데이터베이스에 저장
    public void saveStudent(String studentId, String password, String roomNumber) {
        String query = "INSERT INTO students (student_id, password, room_number) VALUES (?, ?, ?)";
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setString(1, studentId); // 학생 ID
            stmt.setString(2, password);  // 비밀번호
            stmt.setString(3, roomNumber); // 방 번호
            stmt.executeUpdate(); // 쿼리 실행
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // 학생 ID로 학생 정보를 조회
    public String getStudentById(String studentId) {
        String query = "SELECT * FROM students WHERE student_id = ?";
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setString(1, studentId); // 학번 바인딩
            ResultSet rs = stmt.executeQuery(); // 쿼리 실행
            if (rs.next()) {
                return rs.getString("password"); // 학번에 대한 비밀번호 반환
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null; // 학생 정보가 없는 경우 null 반환
    }

    // 데이터베이스 연결 종료
    public void closeConnection() {
        try {
            if (connection != null && !connection.isClosed()) {
                connection.close(); // 연결 닫기
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
