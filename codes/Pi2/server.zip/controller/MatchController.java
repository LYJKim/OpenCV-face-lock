package project.controller;

import java.io.*;
import java.net.*;

// MatchController 클래스: 학생 매칭 관련 메시지를 C 서버로 전송하는 컨트롤러
public class MatchController {
    public static void send(String message) {
        String serverIp = "192.168.65.3"; // C 서버의 IP 주소
        int port = 23232; // C 서버와 통신할 포트 번호

        try (Socket socket = new Socket(serverIp, port)) {
            System.out.println("Connection Success with C server!"); // 연결 성공 메시지 출력

            // 출력 스트림 생성 및 메시지 전송
            PrintWriter output = new PrintWriter(socket.getOutputStream(), true);
            output.println(message); // 메시지 전송
            System.out.println("Message to C server: " + message); // 전송한 메시지 출력

            socket.close(); // 소켓 연결 종료
        } catch (IOException e) {
            e.printStackTrace(); // 예외 발생 시 스택 트레이스 출력
        }
    }
}
